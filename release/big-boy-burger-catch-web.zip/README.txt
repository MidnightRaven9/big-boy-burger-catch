BIG BOY BURGER CATCH - WEB VERSION (v1.0.0)

HOW TO PLAY
1. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari), OR
   serve this folder with:  python3 -m http.server 8000
   then visit http://127.0.0.1:8000/
2. Catch burgers on Big Boy's plate for 10 points each.
3. Dodge the gravy - you have 3 lives.
4. Move with the on-screen LEFT / RIGHT buttons, or the arrow keys (A / D).
5. Pause, mute, and restart from the buttons on screen.

This is a fully offline build: all three original artwork PNGs and all code
are included. Nothing is downloaded at runtime. Your high score is saved
locally in your browser.
