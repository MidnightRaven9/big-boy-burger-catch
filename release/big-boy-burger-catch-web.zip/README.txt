Big Boy Burger Catch v1.1.0 - Offline Web
==========================================

Open index.html in a modern browser. No internet connection or server is required.

This build includes the original mascot/burger/gravy artwork plus the articulated
mascot layers and expression heads generated from the original mascot PNG. The
game now has visible walking, LEFT/RIGHT mirroring, facial expressions, six
difficulty levels, and plate-only scoring.

Controls:
- Hold the on-screen LEFT / RIGHT buttons, tap either half of the playfield,
  or use the keyboard arrow keys / A and D.
- Pause/resume and mute are available in the top bar.

High scores and mute preferences are stored locally in the browser.
